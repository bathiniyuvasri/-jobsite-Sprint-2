import { Component,ElementRef, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from "@angular/router";
import { ItemService } from './../../services/item.service';

@Component({
  selector: 'app-cv-upload',
  templateUrl: './cv-upload.component.html',
  styleUrls: ['./cv-upload.component.css']
})
export class CvUploadComponent implements OnInit {
  emailid: any
  uploadedFiles!: Array<File>; 
  files: any;

  constructor(private router:Router,itemService:ItemService, private elementRef:ElementRef,
    private http:HttpClient) { }

  ngOnInit(): void {
  }
  fileChange(element:any) {
    this.uploadedFiles = element.target.files;
  }

  UploadCV = () =>  {
    alert('UploadCV')
    let inputEl = this.elementRef.nativeElement.querySelector('#file1');
    var formData = new FormData();
    formData.append("emailid", this.emailid);
    formData.append('file1', inputEl.files.item(0));
  
    this.http.post('http://localhost:3000/v1/cv', formData).subscribe(
      
      (response) => console.log(response),
      (error) => console.log(error)
      )
      this.router.navigate(['jobseeker']);


}
}

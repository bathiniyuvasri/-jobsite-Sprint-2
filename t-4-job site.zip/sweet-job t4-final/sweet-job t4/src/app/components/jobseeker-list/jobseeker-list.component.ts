import { Component, OnInit } from '@angular/core';
import { JobseekersService } from "./../../services/jobseekers.service";
@Component({
  selector: 'app-jobseeker-list',
  templateUrl: './jobseeker-list.component.html',
  styleUrls: ['./jobseeker-list.component.css']
})
export class JobseekerListComponent implements OnInit {

  jobseekers:any[] = []
  total_no_of_records:any
  message = ''
  constructor(private jobService:JobseekersService) {
    console.log('constructor')
    //this.getUserList() this is not the right place to other methods / still you can do
  }

  ngOnInit(): void {// Life cycle hooks
    console.log('ngOnInit')
    this.getJobseekersList()
  }

  ngOnDestroy() {
    console.log('ngOnDestroy')
  }

  getJobseekersList = () => {
    this.jobService.getJobseekers().subscribe(
      (result) => {
        this.jobseekers = <any>result;
        this.total_no_of_records = this.jobseekers.length
      },
      (error) => {
        // console.log('error')
        // console.log(error)
        // console.log(error.name)// HttpErrorResponse, if Backend is not running
        //this.message = error.name
        if(error.status === 0 && error.statusText === 'Unknown Error') {
          this.message = 'Backend may be down!'// Backend may not be up and running / HttpErrorResponse
        } else if(error.status === 200 && error.statusText === 'OK') {
          this.message = error.error.text// JWT Error / Any other error
        }
      }
    );

  }

  delete1Jobseekers(jobseekers:any) {
    if(window.confirm(`Are you sure to delete the record with Email Id = ${this.jobseekers}?`)) {
      this.jobService.deleteJobseekers(jobseekers._id)
        .subscribe( data => {
          this.jobseekers = this.jobseekers.filter(u => u !== jobseekers);// Refresh the users Array / remove the deleted record from Array
        })
    }
  }

  setNegative() {
    this.total_no_of_records = -1
  }

  clearMessage() {
    this.message = ''
  }

}

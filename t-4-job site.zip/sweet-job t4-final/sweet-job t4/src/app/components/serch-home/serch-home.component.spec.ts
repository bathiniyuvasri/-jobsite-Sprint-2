import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SerchHomeComponent } from './serch-home.component';

describe('SerchHomeComponent', () => {
  let component: SerchHomeComponent;
  let fixture: ComponentFixture<SerchHomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SerchHomeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SerchHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { JobsService } from "./../../services/jobs.service";
import { Jobs } from "./../../jobs"
import { Router } from '@angular/router';
@Component({
  selector: 'app-serch-home',
  templateUrl: './serch-home.component.html',
  styleUrls: ['./serch-home.component.css']
})
export class SerchHomeComponent implements OnInit {


  Jobs: any[] = []
  searchValue: any
  
  total_no_of_records:any
  message = ''
  constructor(private router: Router, private empService:JobsService) {
    console.log('constructor')
    this.getJobList()
    //this.getUserList() this is not the right place to other methods / still you can do
   }

  ngOnInit(): void {
    console.log('ngOnInit')
    this.getJobList()
  }
  ngOnDestroy() {
    console.log('ngOnDestroy')
  }
  getJobList = () => {
    this.empService.getjob().subscribe(
      (result: any) => {
        this.Jobs = <any>result;
        this.total_no_of_records = this.Jobs.length
      },
      (error: any) => {
        // console.log('error')
        // console.log(error)
        // console.log(error.name)// HttpErrorResponse, if Backend is not running
        //this.message = error.name
        if(error.status === 0 && error.statusText === 'Unknown Error') {
          this.message = 'Backend may be down!'// Backend may not be up and running / HttpErrorResponse
        } else if(error.status === 200 && error.statusText === 'OK') {
          this.message = error.error.text// JWT Error / Any other error
        }
      }
    );

  }


  setNegative() {
    this.total_no_of_records = -1
  }

  clearMessage() {
    this.message = ''
  }
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateJobsaddedComponent } from './update-jobsadded.component';

describe('UpdateJobsaddedComponent', () => {
  let component: UpdateJobsaddedComponent;
  let fixture: ComponentFixture<UpdateJobsaddedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateJobsaddedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateJobsaddedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

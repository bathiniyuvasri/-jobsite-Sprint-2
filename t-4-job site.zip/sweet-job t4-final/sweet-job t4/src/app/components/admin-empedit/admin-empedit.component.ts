import { Component, OnInit } from '@angular/core';
import { EmployerService } from "./../../services/employer.service";
import { ActivatedRoute, Router } from '@angular/router';
import {first} from "rxjs/operators";
@Component({
  selector: 'app-admin-empedit',
  templateUrl: './admin-empedit.component.html',
  styleUrls: ['./admin-empedit.component.css']
})
export class AdminEmpeditComponent implements OnInit {
  _id: any
  username:any
  emailid:any
  password:any
  password2:any
  confirmpassword:any
  phoneno1:any
  phoneno2:any
  address:any
  message=''
  comments:any
  blacklist:any
  companyname:any

  constructor(private route: ActivatedRoute, private userService: EmployerService, private router: Router) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this._id = params['_id'];
      console.log(this._id);
    })
    this.userService.getEmployeeById(this._id)
      .subscribe( data1 => {
        console.log(data1)
        this.username = data1.username;
        this.companyname = data1.companyname;
        this.emailid  = data1.emailid;
        this.password = data1.password;
        this.phoneno1 = data1.phoneno1;
        this.phoneno2 = data1.phoneno2;
        this.address = data1.address;
        this.comments = data1.comments;
        this.blacklist = data1.blacklist;
      },
      error => {
        alert(error);
      });
  }

  editUser() {
    var body = "_id=" + this._id 
        + "&username=" + this.username 
        + "&companyname=" + this.companyname 
        + "&emailid=" + this.emailid 
        + "&password=" + this.password
        + "&phoneno1=" + this.phoneno1
        + "&phoneno2=" + this.phoneno2
        + "&address=" + this.address
        + "&comments=" + this.comments
        + "&blacklist=" + this.blacklist;
    // console.log(body)
    this.userService.updateEmployee(body,this._id)
      .pipe(first())
      .subscribe(
        data => {
          this.router.navigate(['emplist']);
          alert("updated successfully")
        },
        error => {
          alert(error);
        });
  }

}

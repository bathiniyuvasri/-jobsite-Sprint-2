import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AppliedJobseekersListComponent } from './applied-jobseekers-list.component';

describe('AppliedJobseekersListComponent', () => {
  let component: AppliedJobseekersListComponent;
  let fixture: ComponentFixture<AppliedJobseekersListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AppliedJobseekersListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AppliedJobseekersListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

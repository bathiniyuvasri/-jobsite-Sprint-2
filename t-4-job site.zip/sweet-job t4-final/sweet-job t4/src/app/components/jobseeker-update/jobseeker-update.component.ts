import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {first} from "rxjs/operators";
import { JobseekersService } from "./../../services/jobseekers.service";
@Component({
  selector: 'app-jobseeker-update',
  templateUrl: './jobseeker-update.component.html',
  styleUrls: ['./jobseeker-update.component.css']
})
export class JobseekerUpdateComponent implements OnInit {

  _id: any
  username:any
  emailid:any
  password:any
  password2:any
  confirmpassword:any
  phoneno1:any
  phoneno2:any
  address:any
  qualification:any
  experience:any
  preferredplace:any
  message=''
  comments:any

  constructor(private route: ActivatedRoute, private userService: JobseekersService, private router: Router) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this._id = params['_id'];
      console.log(this._id);
    })
    this.userService.getJobseekersById(this._id)
      .subscribe( data1 => {
        console.log(data1)
        this.username = data1.username;
        this.emailid  = data1.emailid;
        this.password = data1.password;
        this.phoneno1 = data1.phoneno1;
        this.phoneno2 = data1.phoneno2;
        this.address = data1.address;
        this.experience = data1.experience;
        this.qualification = data1.qualification;
        this.preferredplace = data1.preferredplace;
      },
      error => {
        alert(error);
      });
  }

  editUser() {
    var body = "_id=" + this._id 
        + "&username=" + this.username 
        + "&emailid=" + this.emailid 
        + "&password=" + this.password
        + "&phoneno1=" + this.phoneno1
        + "&phoneno2=" + this.phoneno2
        + "&address=" + this.address
        + "&experience=" + this.experience
        + "&qualification=" + this.qualification
        + "&preferredplace=" + this.preferredplace;
    // console.log(body)
    this.userService.updateJobseekers(body,this._id)
      .pipe(first())
      .subscribe(
        data => {
          this.router.navigate(['jobseeker']);
          alert("updated successfully")
        },
        error => {
          alert(error);
        });
  }


}

import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { JobseekersService } from "./../../services/jobseekers.service";
@Component({
  selector: 'app-jobseeker-register',
  templateUrl: './jobseeker-register.component.html',
  styleUrls: ['./jobseeker-register.component.css']
})
export class JobseekerRegisterComponent implements OnInit {

  username:any
  emailid:any
  password:any
  password2:any
  confirmpassword:any
  phoneno1:any
  phoneno2:any
  address:any
  qualification:any
  experience:any
  preferredplace:any

  
  message=''
 
  constructor(private router: Router, private userService: JobseekersService) {}
      
  ngOnInit(): void {
  }
  addUser = () => {
    var body = "username=" + this.username 
        + "&emailid=" + this.emailid 
        + "&password=" + this.password
        + "&address=" + this.address
        + "&phoneno1=" + this.phoneno1
        + "&phoneno2=" + this.phoneno2
        + "&qualification=" + this.qualification
        + "&experience=" + this.experience
        + "&preferredplace=" + this.preferredplace
        + "&comments=" + ' '
        + "&blacklist=" + false;

    this.userService.createUser(body)
      .subscribe( data => {
        console.log("registered successfully!!")
        this.router.navigate(['/seekerlogin']);
        alert("register successfully")
      },
      (error) => {
        this.message = error.error
        alert("this email id already used")
      });    
  }

  clearMessage() {
    this.message = ''
  }

}

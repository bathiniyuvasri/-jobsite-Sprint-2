import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddedEmployeeJoblistComponent } from './added-employee-joblist.component';

describe('AddedEmployeeJoblistComponent', () => {
  let component: AddedEmployeeJoblistComponent;
  let fixture: ComponentFixture<AddedEmployeeJoblistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddedEmployeeJoblistComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddedEmployeeJoblistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

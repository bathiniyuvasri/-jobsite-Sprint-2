import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seekerpassword',
  templateUrl: './seekerpassword.component.html',
  styleUrls: ['./seekerpassword.component.css']
})
export class SeekerpasswordComponent implements OnInit {

  old_password:any
  new_password:any
  confirm_new_password:any
  
  constructor() { }

  ngOnInit(): void {
  }

}

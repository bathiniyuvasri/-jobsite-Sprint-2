import { Pipe, PipeTransform } from '@angular/core';
import { Jobs } from "./jobs"
@Pipe({
  name: 'searchfilter'
})
export class SearchfilterPipe implements PipeTransform {

  transform(Jobs: Jobs[], searchValue:string): Jobs[] {

    if (!Jobs || !searchValue){
      return Jobs;
    }
    return Jobs.filter(job =>
      job.joblocation.toLocaleLowerCase().includes(searchValue.toLocaleLowerCase()));
  }

}

export class Jobs {
    jobname:any
    companyname:any
    jobdescription:any
    minimumexperience:any
    maximumexperience:any
    minimumsalary:any
    maximumsalary:any
    joblocation:any
    noticeperiod:any
    mainskill:any
    subskills:any
    numberofpost:any
  
    constructor(joblocation: any,jobname:any,companyname:any,jobdescription:any, minimumexperience:any, maximumexperience:any,minimumsalary:any,maximumsalary:any,noticeperiod:any,mainskill:any,subskills:any, numberofpost:any){
        this.joblocation=joblocation;
        this.companyname=companyname;
        this.jobname=jobname;
        this.jobdescription=jobdescription; 
        this.minimumexperience=minimumexperience;
        this.maximumexperience=maximumexperience;
        this.minimumsalary=minimumsalary;
        this.maximumsalary=maximumsalary;
        this.noticeperiod=noticeperiod;
        this.mainskill=mainskill;
        this.subskills=subskills;
        this.numberofpost=numberofpost;
  
    }
  }
  
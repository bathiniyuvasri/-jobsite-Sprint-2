import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomePageComponent } from './components/home-page/home-page.component';
import { FooterComponent } from './components/footer/footer.component';
import { SiteLayoutComponent } from './components/site-layout/site-layout.component';
import { EmployerComponent } from './components/employer/employer.component';
import { JobseekersComponent } from './components/jobseekers/jobseekers.component';
import { EmployerAddjobComponent } from './components/employer-addjob/employer-addjob.component';
import { JobseekersAppComponent } from './components/jobseekers-app/jobseekers-app.component';
import { JobseekersLoginComponent } from './components/jobseekers-login/jobseekers-login.component';
import { EmployerLoginComponent } from './components/employer-login/employer-login.component';
import { HeaderComponent } from './components/header/header.component';
import { EmployeeRegisterComponent } from './components/employee-register/employee-register.component';
import { JobseekerRegisterComponent } from './components/jobseeker-register/jobseeker-register.component';
import { AddedEmployeeJoblistComponent } from './components/added-employee-joblist/added-employee-joblist.component';
import { SearchfilterPipe } from './searchfilter.pipe';
import { SearchJobsComponent } from './components/search-jobs/search-jobs.component';
import { AdminComponent } from './components/admin/admin.component';
import { AdminLoginComponent } from './components/admin-login/admin-login.component';
import { EmployeeListComponent } from './components/employee-list/employee-list.component';
import { JobseekerListComponent } from './components/jobseeker-list/jobseeker-list.component';
import { JobseekerUpdateComponent } from './components/jobseeker-update/jobseeker-update.component';
import { SeekerpasswordComponent } from './components/seekerpassword/seekerpassword.component';
import { EmployerEditComponent } from './components/employer-edit/employer-edit.component';
import { JobsListComponent } from './components/jobs-list/jobs-list.component';
import { UpdateJobsaddedComponent } from './components/update-jobsadded/update-jobsadded.component';
import { SerchHomeComponent } from './components/serch-home/serch-home.component';
import { AdminEmpeditComponent } from './components/admin-empedit/admin-empedit.component';
import { AdminJobseekereditComponent } from './components/admin-jobseekeredit/admin-jobseekeredit.component';
import { CvUploadComponent } from './components/cv-upload/cv-upload.component';
import { AppliedJobComponent } from './components/applied-job/applied-job.component';
import { AppliedJobseekersListComponent } from './components/applied-jobseekers-list/applied-jobseekers-list.component';


@NgModule({
  declarations: [
    AppComponent,
    HomePageComponent,
    FooterComponent,
    SiteLayoutComponent,
    EmployerComponent,
    JobseekersComponent,
    EmployerAddjobComponent,
    JobseekersAppComponent,
    JobseekersLoginComponent,
    EmployerLoginComponent,
    HeaderComponent,
    EmployeeRegisterComponent,
    JobseekerRegisterComponent,
    AddedEmployeeJoblistComponent,
    SearchfilterPipe,
    SearchJobsComponent,
    AdminComponent,
    AdminLoginComponent,
    EmployeeListComponent,
    JobseekerListComponent,
    JobseekerUpdateComponent,
    SeekerpasswordComponent,
    EmployerEditComponent,
    JobsListComponent,
    UpdateJobsaddedComponent,
    SerchHomeComponent,
    AdminEmpeditComponent,
    AdminJobseekereditComponent,
    CvUploadComponent,
    AppliedJobComponent,
    AppliedJobseekersListComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [SiteLayoutComponent]
})
export class AppModule { }
